function Contacts () {
    return (
        <div className="wrap">
            <h2>Contacts</h2>
        </div>
    )
}

export default Contacts;